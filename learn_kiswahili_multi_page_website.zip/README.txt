LEARN KISWAHILI KENYA — MULTI-PAGE WEBSITE

FILES
- index.html       Home page
- courses.html     Course catalogue
- level1.html      Beginner course topics
- level2.html      Elementary course topics
- level3.html      Intermediate course topics
- level4.html      Advanced course topics
- lesson.html      Lesson reader, pronunciation and quizzes
- dashboard.html  Local progress dashboard
- pricing.html     Premium and M-Pesa information
- styles.css       Shared design
- app.js           Shared course data and page behaviour

PUBLISH ON GITHUB PAGES
1. Open your GitHub repository.
2. Upload ALL these files and folders' contents into the same root location as your current index.html.
3. If GitHub asks whether to replace index.html, choose replace.
4. Commit the changes.
5. Wait for GitHub Pages to publish, then refresh your website.

IMPORTANT LIMITATIONS
- This is a front-end starter. Only some lessons have full lesson notes and quizzes; remaining topics are outlines awaiting full content.
- Pronunciation uses browser text-to-speech; it is not recorded native-speaker audio. Voice availability varies by device/browser.
- Progress is stored in localStorage on one browser/device, not in secure cloud student accounts.
- All levels are marked as premium in the course design, but this does not securely block direct URLs. Secure paywalls require authentication and server-side authorisation.
- M-Pesa is not connected. Do not put Daraja secrets in HTML/JavaScript. Use a secure backend for STK Push, callback validation and payment-based enrolment.
- KSh 300 is the stated price per live class only. Full course prices and real Paybill/Till details were not supplied, so they are not invented here.
