LEARNING KISWAHILI ADVENTURE — FIRST PLAYABLE DEMO

FILES
- index.html: complete game (HTML, CSS, JavaScript embedded)
- manifest.json: Android/PWA installation metadata
- sw.js: basic offline caching

WHAT WORKS
- Four Kiswahili mission levels
- Multiple-choice questions with explanations
- Points, coins, progress and next-level unlocking
- Progress saved in this browser/device
- Mobile-friendly layout and basic PWA support

IMPORTANT LIMITATIONS
- This is a demo. Points/level unlocks are stored locally and are not secure.
- There is no student login, cloud progress, real M-Pesa payment, or server-side verification.
- Do not sell access based on client-only unlock logic; a user can modify local browser storage.
- The PWA install prompt varies by browser. A secure HTTPS deployment is required for service workers.

DEPLOY TO EXISTING CLOUDFLARE PROJECT
1. Back up/download your current website files first.
2. If the existing project uses GitHub: upload/commit these files into the correct project directory, preserving any existing site content. Check the build output directory in Cloudflare Pages.
3. If using Direct Upload: prepare the full site folder with index.html at its root, then use Workers & Pages > your Pages project > Create new deployment / upload flow.
4. Deploy and open the preview URL first. Verify the existing homepage before replacing production.
5. For a separate game route, put the files in a folder named "game" so the page is available at /game/ (if your deployment setup preserves that folder).
6. On Android Chrome, open the deployed HTTPS URL; use the browser menu > Install app or Add to Home screen if offered.

CLOUDFLARE STATIC HTML DOCS
https://developers.cloudflare.com/pages/framework-guides/deploy-anything/

NEXT PHASE
- Add a server-side account and database.
- Integrate Safaricom Daraja/M-Pesa with a secure backend and callback verification.
- Unlock paid content only after the backend verifies a successful payment.
- Keep secrets and API keys out of HTML/JavaScript.
